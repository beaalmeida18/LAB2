/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.carro0;

/**
 *
 * @author Usuario
 */
public class Carro0 {

    /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.senac.sp.aula3;

/**
 *
 * @beatriz bizerra de almeida 
 */
public class Carro {
    
    private static String fabricante;
    
    private String[] Rodas;
    
    private String cor;
    
    private String modelo;
    
    private int velocidadeAtual;

//Modelo:
    
public String getModelo() {
        return modelo;
}

//Definir a cor do veículo
public void setModelo(String pModelo) {
        this.modelo = pModelo;
}

//Carro:
        
public String getCor() {
        return cor;
}

//Definir a cor do veículo
public void setCor(String pCor) {
        this.cor = pCor;
}

//Acelerar:
    public int getVelocidadeAtual() {
        return velocidadeAtual;
    }
    
public void acelerar(){
        this.velocidadeAtual+=10;
    }

public void acelerar(int numVelocidade){
          this.velocidadeAtual+=numVelocidade;
    }

public void frear(){
        this.velocidadeAtual-=10;
    }

}
    }
}
