/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.main0;

/**
 *
 * @author Usuario
 */
public class Main0 {

    package br.senac.sp.aula3;

import javax.swing.JOptionPane;


/**
 *
 * @beatriz bizerra de almeida
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
    Carro Mazda = new Carro();
    Mazda.setModelo("Rx7");
    
    Carro carroRodizio = new Carro();
    carroRodizio.setModelo("787B");
    carroRodizio.setCor(“branco");
    carroRodizio.acelerar();
    
    
    JOptionPane.showMessageDialog(null, "modelo: " + carroRodizio.getModelo() + ", cor: " + carroRodizio.getCor() + ", velocidade: " + carroRodizio.getVelocidadeAtual());
    }
    
    
}
    }
}
